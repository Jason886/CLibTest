dofile("myassert.lua")

function func ()
 return 5
end
