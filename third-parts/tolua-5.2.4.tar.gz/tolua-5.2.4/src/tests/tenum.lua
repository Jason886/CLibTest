dofile("myassert.lua")

local a = FIRST
local b = SECOND

assert(checkenum(a)==TRUE)
assert(checkenum(b)==FALSE)

print("Enum test OK")